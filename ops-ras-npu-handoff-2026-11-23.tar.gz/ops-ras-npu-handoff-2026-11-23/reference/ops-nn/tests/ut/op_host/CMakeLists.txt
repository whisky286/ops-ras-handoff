# ----------------------------------------------------------------------------
# Copyright (c) 2025-2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------

cmake_minimum_required(VERSION 3.16)

if(UT_TEST_ALL OR OP_HOST_UT OR OP_GRAPH_UT OR OP_API_UT)
    file(GLOB SUBDIRECTORIES LIST_DIRECTORIES true RELATIVE ${CMAKE_CURRENT_SOURCE_DIR} ${CMAKE_CURRENT_SOURCE_DIR}/*)
    foreach(SUBDIR ${SUBDIRECTORIES})
        if(EXISTS ${CMAKE_CURRENT_SOURCE_DIR}/${SUBDIR}/CMakeLists.txt)
            add_subdirectory(${SUBDIR})
        endif()
    endforeach()

    if(EXISTS ${OPS_NN_DIR}/common/tests/ut/framework/CMakeLists.txt)
        # 全量模式(ASCEND_OP_NAME 空)接入；--ops 模式仅当命中 common 框架插件算子时接入
        set(_nn_include_common_fw OFF)
        if(NOT ASCEND_OP_NAME)
            set(_nn_include_common_fw ON)
        else()
            file(GLOB _fw_plugins ${OPS_NN_DIR}/common/src/framework/*_onnx_plugin.cpp)
            foreach(_p ${_fw_plugins})
                get_filename_component(_n ${_p} NAME_WE)
                string(REGEX REPLACE "_onnx_plugin$" "" _op "${_n}")
                if(_op IN_LIST ASCEND_OP_NAME)
                    set(_nn_include_common_fw ON)
                endif()
            endforeach()
        endif()
        if(_nn_include_common_fw)
            add_subdirectory(${OPS_NN_DIR}/common/tests/ut/framework
                            ${CMAKE_CURRENT_BINARY_DIR}/common_op_framework)
        endif()
    endif()

    ## add ophost_nn_ut so
    if(TARGET ${OPHOST_NAME}_infer_obj)
        message(STATUS "Found infershape file.")
        set(OPHOST_INFER_OBJ_SRCS $<TARGET_OBJECTS:${OPHOST_NAME}_infer_obj>)
    else()
        message(WARNING "Infershape file Not Found.")
        set(OPHOST_INFER_OBJ_SRCS "${CMAKE_SOURCE_DIR}/tests/ut/empty.cpp")
    endif()
    add_library(ophost_${PKG_NAME}_ut SHARED
        ${OPHOST_INFER_OBJ_SRCS}
        $<$<TARGET_EXISTS:opbase_util_objs>:$<TARGET_OBJECTS:opbase_util_objs>>
        $<$<TARGET_EXISTS:opbase_infer_objs>:$<TARGET_OBJECTS:opbase_infer_objs>>
    )
    target_compile_options(ophost_${PKG_NAME}_ut PRIVATE -fPIC)
    target_compile_definitions(ophost_${PKG_NAME}_ut PRIVATE LOG_CPP)
    target_link_libraries(ophost_${PKG_NAME}_ut PRIVATE
        $<BUILD_INTERFACE:intf_llt_pub_asan_cxx17>
        -Wl,--whole-archive
        rt2_registry_static
        -Wl,--no-whole-archive
        -Wl,--no-as-needed
        metadef
        -Wl,--as-needed
        error_manager
        exe_graph
        graph_base
        gtest
        graph
        platform
        register
        opp_registry
        tiling_api
        dlog
        dl
    )

    ## add ophost ut exe:  nn_op_host_ut
    set(OP_HOST_UT_EXE ${PKG_NAME}_op_host_ut)
    add_executable(${OP_HOST_UT_EXE}
        test_op_host_main.cpp
        ${CMAKE_SOURCE_DIR}/tests/ut/acl_platform_stub.cpp
    )

    # 当前桩函数实现不完整，优先从环境变量中链接so
    set_target_properties(${OP_HOST_UT_EXE} PROPERTIES
        SKIP_BUILD_RPATH TRUE
    )

    target_compile_definitions(${OP_HOST_UT_EXE} PRIVATE LOG_CPP)
    target_include_directories(${OP_HOST_UT_EXE} PRIVATE ${ASCEND_DIR}/${SYSTEM_PREFIX}/pkg_inc ${ASCEND_DIR}/include)
    target_compile_options(${OP_HOST_UT_EXE} PUBLIC -fPIE -fno-access-control)
    target_link_libraries(${OP_HOST_UT_EXE} PRIVATE
        $<BUILD_INTERFACE:intf_llt_pub_asan_cxx17>
        -Wl,--whole-archive
        $<$<TARGET_EXISTS:${OP_TILING_MODULE_NAME}_static_lib>:${OP_TILING_MODULE_NAME}_static_lib>
        $<$<TARGET_EXISTS:${OP_INFERSHAPE_MODULE_NAME}_static_lib>:${OP_INFERSHAPE_MODULE_NAME}_static_lib>
        $<$<TARGET_EXISTS:${OP_FRAMEWORK_MODULE_NAME}_static_lib>:${OP_FRAMEWORK_MODULE_NAME}_static_lib>
        -Wl,--no-whole-archive
        -Wl,--no-as-needed
        metadef
        # Match the SDK tiling dependency, including nnopbase error-code registration.
        nnopbase
        -Wl,--as-needed
        error_manager
        exe_graph
        graph_base
        gtest
        graph
        platform
        register
        opp_registry
        tiling_api
        dlog
        unified_dlog
        acl_rt
        dl
    )

    target_link_directories(${OP_HOST_UT_EXE} PRIVATE ${ASCEND_DIR}/${SYSTEM_PREFIX}/lib64)

    add_dependencies(${OP_HOST_UT_EXE} json)

    if(ENABLE_UT_EXEC)
        if(${ENABLE_ASAN} STREQUAL "TRUE")
            execute_process(
                COMMAND ${CMAKE_C_COMPILER} -print-file-name=libasan.so
                OUTPUT_VARIABLE LIBASAN_PATH
                OUTPUT_STRIP_TRAILING_WHITESPACE
                RESULT_VARIABLE result
            )
            if(NOT result EQUAL 0)
                message(FATAL_ERROR "compiler not support asan, please disable asan")
            endif()

            execute_process(
                COMMAND ${CMAKE_C_COMPILER} -print-file-name=libstdc++.so
                OUTPUT_VARIABLE LIBSTDC_PATH
                OUTPUT_STRIP_TRAILING_WHITESPACE
                RESULT_VARIABLE stdc_result
            )
            if(NOT stdc_result EQUAL 0)
                message(FATAL_ERROR "not find libstdc++.so, please confirm.")
            endif()
            add_custom_command(
                TARGET ${OP_HOST_UT_EXE}
                POST_BUILD
                COMMAND
                    ${CMAKE_COMMAND} -E env LD_LIBRARY_PATH=$ENV{LD_LIBRARY_PATH} BUILD_PATH=${BUILD_PATH}
                    LD_PRELOAD=${LIBASAN_PATH}:${LIBSTDC_PATH}
                    ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0
                    ./${OP_HOST_UT_EXE}
                    COMMENT "Run ops op_host utest with asan"
            )
        else()
            add_custom_command(
                TARGET ${OP_HOST_UT_EXE} POST_BUILD
                COMMAND ./${OP_HOST_UT_EXE}
                COMMENT "Run ops op_host utest"
            )
        endif()
    endif()

    if(${ENABLE_VALGRIND} STREQUAL "TRUE")
        add_custom_command(
            TARGET ${OP_HOST_UT_EXE} POST_BUILD
            COMMAND valgrind --undef-value-errors=no --leak-check=full ./${OP_HOST_UT_EXE}
            COMMENT "Run ops op_host utest by valgrind"
        )
    endif()
endif()
