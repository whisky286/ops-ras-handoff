#!/usr/bin/env bash
# Read-only environment collection; this does not validate CANN or NPU behavior.
set -eu
repo=.
output=results/environment.txt
if [ "$#" -ge 1 ]; then repo="$1"; fi
if [ "$#" -ge 2 ]; then output="$2"; fi
python3 - "$repo" "$output" <<'PY'
import datetime
import os
import pathlib
import platform
import shutil
import subprocess
import sys

repo = pathlib.Path(sys.argv[1]).resolve()
output = pathlib.Path(sys.argv[2]).resolve()
output.parent.mkdir(parents=True, exist_ok=True)
lines = [
    "ops-ras server environment collection (not a test PASS)",
    "captured_at_utc=" + datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "platform=" + platform.platform(),
    "architecture=" + platform.machine(),
    "repository=" + str(repo),
]
for name in (
    "ASCEND_HOME_PATH", "ASCEND_OPP_PATH", "ASCEND_CUSTOM_OPP_PATH",
    "LD_LIBRARY_PATH", "ASCEND_RT_VISIBLE_DEVICES", "ASCEND_VISIBLE_DEVICES",
):
    lines.append(name + "=" + os.environ.get(name, "<unset>"))

def record(command, timeout=20):
    executable = shutil.which(command[0])
    lines.append("\n$ " + " ".join(command))
    lines.append("executable=" + str(executable))
    if not executable:
        lines.append("NOT AVAILABLE")
        return
    try:
        result = subprocess.run(command, cwd=repo, text=True, capture_output=True, timeout=timeout)
        lines.append("exit_code=" + str(result.returncode))
        lines.append(result.stdout.rstrip())
        if result.stderr:
            lines.append("stderr:\n" + result.stderr.rstrip())
    except (OSError, subprocess.TimeoutExpired) as exc:
        lines.append("COLLECTION ERROR: " + str(exc))

for command in (
    ["git", "rev-parse", "HEAD"],
    ["git", "status", "--short", "--branch"],
    ["bash", "--version"],
    ["python3", "--version"],
    ["cmake", "--version"],
    ["ninja", "--version"],
    ["g++", "--version"],
    ["gcc", "--version"],
    ["clang++", "--version"],
    ["valgrind", "--version"],
    ["openssl", "version"],
    ["npu-smi", "info"],
    ["df", "-h", str(repo)],
    ["free", "-h"],
):
    record(command)

home = os.environ.get("ASCEND_HOME_PATH")
version_paths = [pathlib.Path("/usr/local/Ascend/driver/version.info")]
if home:
    base = pathlib.Path(home)
    version_paths.extend([base / "version.cfg", base / "version.info"])
    version_paths.extend(sorted((base / "share/info").glob("*/version.info"))[:50])
for path in version_paths:
    if path.is_file():
        lines.append("\nVERSION FILE: " + str(path.resolve()))
        lines.append(path.read_text(encoding="utf-8", errors="replace")[:8192])
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("Saved read-only environment inventory to " + str(output))
PY
