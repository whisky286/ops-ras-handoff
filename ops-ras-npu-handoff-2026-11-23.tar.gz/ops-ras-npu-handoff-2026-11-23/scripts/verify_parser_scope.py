#!/usr/bin/env python3
"""Check three existing parser behaviors; no CANN or device is required."""

import argparse
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    source = args.repo.resolve() / "scripts/kernel/binary_script/parser_ini.py"
    spec = importlib.util.spec_from_file_location("ras_parser_under_test", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cases = [
        (
            "valid_input_and_output",
            {"Demo": {"input0": {"name": "x", "paramType": "required"},
                      "output0": {"name": "y", "paramType": "required"}}},
            True,
        ),
        ("missing_param_type", {"Demo": {"input0": {"name": "x"}}}, False),
        ("invalid_param_type", {"Demo": {"output0": {"name": "y", "paramType": "bad"}}}, False),
    ]
    rows = []
    for name, data, expected in cases:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            actual = module.check_op_info(data)
        rows.append({
            "case": name, "expected": expected, "actual": actual,
            "passed": actual == expected, "stdout": output.getvalue(),
        })
    report = {
        "source": str(source), "cases": rows,
        "passed": all(row["passed"] for row in rows),
        "scope": "Required input/output keys and paramType only; not shapeType/needCompile validation.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(str(sum(row["passed"] for row in rows)) + "/3 parser behavior checks matched.")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
