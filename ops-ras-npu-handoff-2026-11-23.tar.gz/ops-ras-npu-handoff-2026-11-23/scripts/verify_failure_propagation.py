#!/usr/bin/env python3
"""Check real Bash wrappers using temporary inputs and a controlled child.

--expect baseline asserts reproduction of the two known defects.
--expect correct asserts that failed work returns nonzero. No CANN/NPU runs.
"""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def execute(command, *, cwd, env):
    result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True, timeout=30)
    return {
        "command": command,
        "exit_code": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--expect", choices=("baseline", "correct"), default="correct")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    merge = repo / "scripts/util/merge_aicpu_info_json.sh"
    wrapper = repo / "scripts/kernel/binary_script/build_binary_opc.sh"
    helper = repo / "scripts/kernel/binary_script/get_threadnum_with_op.sh"
    for path in (merge, wrapper, helper):
        if not path.is_file():
            parser.error("Required production source missing: " + str(path))
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    rows = []
    with tempfile.TemporaryDirectory(prefix="ras-failure-propagation-") as tmp:
        folder = Path(tmp)
        first, second, output = [folder / name for name in ("first.json", "second.json", "output.json")]
        first.write_text('{"A": {}}', encoding="utf-8")
        second.write_text('{"B": {}}', encoding="utf-8")
        for case_id, extra, expect_error, expected_keys in (
            ("merge_missing_input", folder / "missing.json", True, None),
            ("merge_valid_control", second, False, {"A", "B"}),
        ):
            row = execute(
                ["bash", str(merge), str(repo), str(output), str(first), str(extra)],
                cwd=folder, env=env,
            )
            row.update(case_id=case_id, error_expected=expect_error)
            try:
                row["output_keys"] = sorted(json.loads(output.read_text()).keys())
            except (OSError, ValueError, AttributeError) as exc:
                row["output_keys"] = None
                row["output_read_error"] = str(exc)
            row["passed"] = (
                row["exit_code"] == 0
                if args.expect == "baseline" or not expect_error
                else row["exit_code"] != 0
            )
            if expected_keys is not None:
                row["passed"] = row["passed"] and row["output_keys"] == sorted(expected_keys)
            if args.expect == "baseline" and expect_error:
                row["passed"] = row["passed"] and "[ERROR]" in row["stdout"]
            rows.append(row)

        # Source the real helper; replace only the wrapper's child generator
        # with a real subprocess with a controlled exit status. This tests
        # production wrapper propagation, not OPC generation or NPU behavior.
        shutil.copyfile(helper, folder / helper.name)
        child = folder / "build_binary_opc_gen_task.sh"
        for child_code in (7, 0):
            child.write_text(
                '#!/bin/bash\nprintf "controlled child result\\n"\nexit ' + str(child_code) + "\n",
                encoding="utf-8",
            )
            row = execute(
                [
                    "bash", str(wrapper), "Demo", "ascend910b", str(folder / "output"),
                    "Release", "FALSE", "FALSE", "FALSE",
                ],
                cwd=folder, env=env,
            )
            expect_error = child_code != 0
            row.update(
                case_id="opc_child_" + str(child_code),
                error_expected=expect_error,
                controlled_child_exit_code=child_code,
            )
            row["passed"] = (
                row["exit_code"] == 0
                if args.expect == "baseline" or not expect_error
                else row["exit_code"] != 0
            )
            if args.expect == "baseline" and expect_error:
                row["passed"] = row["passed"] and "[ERROR]" in row["stdout"]
            rows.append(row)

    report = {
        "repository": str(repo),
        "expectation": args.expect,
        "meaning": (
            "PASS means the known bad baseline behavior was reproduced, not functional correctness."
            if args.expect == "baseline"
            else "PASS means failed work returned nonzero and normal controls still succeeded."
        ),
        "npu_or_opc_execution": False,
        "cases": rows,
        "passed": all(row["passed"] for row in rows),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for row in rows:
        print(row["case_id"], "exit=" + str(row["exit_code"]), "matched=" + str(row["passed"]))
    print(report["meaning"])
    print("Report: " + str(args.output.resolve()))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
